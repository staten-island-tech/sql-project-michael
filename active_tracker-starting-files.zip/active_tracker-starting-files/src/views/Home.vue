<template>
  <div></div>
</template>

<script>
export default {
  name: "Home",
  components: {},
  setup() {
    // Create data / vars

    // Get data

    // Run data function

    return {};
  },
};
</script>
