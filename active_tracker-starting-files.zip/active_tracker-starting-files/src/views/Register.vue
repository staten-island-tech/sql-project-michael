<template>
  <div></div>
</template>

<script>
export default {
  name: "register",
  setup() {
    // Create data / vars

    // Register function

    return {};
  },
};
</script>
