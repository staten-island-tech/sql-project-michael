<template>
  <div></div>
</template>

<script>
export default {
  name: "view-workout",
  setup() {
    // Create data / vars

    // Get current Id of route

    // Get workout data

    // Delete workout

    // Edit mode

    // Add exercise

    // Delete exercise

    // Update Workout

    return {};
  },
};
</script>
