<template>
  <div></div>
</template>

<script>
export default {
  name: "create",
  setup() {
    // Create data

    // Add exercise

    // Delete exercise

    // Listens for chaging of workout type input

    // Create workout

    return {};
  },
};
</script>
