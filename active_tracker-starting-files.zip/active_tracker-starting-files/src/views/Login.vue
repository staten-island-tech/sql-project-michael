<template>
  <div></div>
</template>

<script>
export default {
  name: "login",
  setup() {
    // Create data / vars

    // Login function

    return {};
  },
};
</script>
